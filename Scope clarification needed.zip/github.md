repo: karishok/NeedToBuy
branch: claude/grill-me-skill-usage-otd4c9

## Last sync
date: 2026-08-20T06:42:35Z

### Updated in this project
- Read docs/mvp-decisions.md to ground the prototype's scope (age grid, roles, Ozon-only, OTP auth, no booking).
- No app UI existed in the repo yet — prototype built from scratch on the Organic design system.

## Screen map
| Project screen | Repo source |
| --- | --- |
| All screens (Wishlist.dc.html) | docs/mvp-decisions.md (product spec, no existing UI code) |
